#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
导出模块
"""

from .result_exporter import export_screening_results

__all__ = ['export_screening_results']
